var yourName = prompt("Enter your name: ");
var occupation = prompt("Enter your occuation: ");
var salary = prompt("Enter a number betweek 2 and 100: ");
var yourExp = prompt("Enter a saying or expression: ");
var verb = prompt("Enter an action verb not ending in ING: ");
var adjective = prompt("Enter an adjective: ");
var pluralNoun = prompt("Enter a plural noun: ");

document.write(yourName + " just got offered a new job position as a " + occupation + " making " + salary + " dollars per hour. '' " + yourExp + " ,'' you say! Your job requires you to " + verb + " and make " + adjective + " " + pluralNoun + ".");